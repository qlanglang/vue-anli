<template>
  <div id="app">
    App根组件
  </div>
</template>

<script>

export default {
  name: 'app',
  components: {
    
  }
}
</script>

<style>

</style>
